# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Värd: 127.0.0.1 (MySQL 5.6.34)
# Databas: 040worksample_db
# Genereringstid: 2019-02-17 11:01:15 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Tabelldump course1
# ------------------------------------------------------------

DROP TABLE IF EXISTS `course1`;

CREATE TABLE `course1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int(11) DEFAULT NULL,
  `course_date` date DEFAULT NULL,
  `company_name` text,
  `company_phone` int(11) DEFAULT NULL,
  `company_email` text,
  `participant_name` text,
  `participant_phone` int(11) DEFAULT NULL,
  `participant_email` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabelldump course2
# ------------------------------------------------------------

DROP TABLE IF EXISTS `course2`;

CREATE TABLE `course2` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int(11) DEFAULT NULL,
  `course_date` date DEFAULT NULL,
  `company_name` text,
  `company_phone` int(11) DEFAULT NULL,
  `company_email` text,
  `participant_name` text,
  `participant_phone` int(11) DEFAULT NULL,
  `participant_email` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabelldump course3
# ------------------------------------------------------------

DROP TABLE IF EXISTS `course3`;

CREATE TABLE `course3` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int(11) DEFAULT NULL,
  `course_date` date DEFAULT NULL,
  `company_name` text,
  `company_phone` int(11) DEFAULT NULL,
  `company_email` text,
  `participant_name` text,
  `participant_phone` int(11) DEFAULT NULL,
  `participant_email` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabelldump course4
# ------------------------------------------------------------

DROP TABLE IF EXISTS `course4`;

CREATE TABLE `course4` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int(11) DEFAULT NULL,
  `course_date` date DEFAULT NULL,
  `company_name` text,
  `company_phone` int(11) DEFAULT NULL,
  `company_email` text,
  `participant_name` text,
  `participant_phone` int(11) DEFAULT NULL,
  `participant_email` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Tabelldump course5
# ------------------------------------------------------------

DROP TABLE IF EXISTS `course5`;

CREATE TABLE `course5` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int(11) DEFAULT NULL,
  `course_date` date DEFAULT NULL,
  `company_name` text,
  `company_phone` int(11) DEFAULT NULL,
  `company_email` text,
  `participant_name` text,
  `participant_phone` int(11) DEFAULT NULL,
  `participant_email` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
